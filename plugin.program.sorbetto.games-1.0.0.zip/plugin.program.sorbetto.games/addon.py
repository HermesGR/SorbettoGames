# -*- coding: utf-8 -*-
"""SorbettoGames 1.0.0 — Kodi 21 / Python 3."""
import os, sys, json, urllib.request, urllib.parse, zipfile, shutil, subprocess, re
import xbmc, xbmcgui, xbmcaddon, xbmcvfs

ADDON = xbmcaddon.Addon()
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
GAMES_DIR = os.path.join(PROFILE, 'games')
os.makedirs(GAMES_DIR, exist_ok=True)
ALLOWED_EXTS = ('.cue', '.chd', '.pbp', '.iso', '.bin')
EXCLUDED_ASSETS = {'sorbetto-catalog.json', 'plugin.program.sorbetto.games-1.0.0.zip', 'repository.sorbetto.games-1.0.0.zip'}

def notify(message, heading='SorbettoGames', time=5000):
    xbmcgui.Dialog().notification(heading, str(message), time=time)

def safe_id(value):
    value = re.sub(r'[^A-Za-z0-9._-]+', '-', str(value)).strip('.-_')
    return value[:100] or 'game'

def get_json(url):
    req = urllib.request.Request(url, headers={'User-Agent':'SorbettoGames-Kodi/1.0.0','Accept':'application/vnd.github+json'})
    with urllib.request.urlopen(req, timeout=25) as response:
        return json.loads(response.read().decode('utf-8'))

def repository_and_release():
    repo = ADDON.getSetting('github_repo').strip() or 'HermesGR/SorbettoGames'
    if not re.match(r'^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$', repo):
        raise ValueError('Το GitHub repository πρέπει να έχει μορφή owner/name.')
    tag = ADDON.getSetting('release_tag').strip()
    endpoint = 'https://api.github.com/repos/' + repo + '/releases/'
    endpoint += 'tags/' + urllib.parse.quote(tag, safe='') if tag else 'latest'
    return repo, get_json(endpoint)

def load_catalog():
    repo, release = repository_and_release()
    assets = release.get('assets', [])
    by_name = {str(a.get('name','')): a for a in assets}
    manifest_asset = by_name.get('sorbetto-catalog.json')
    if manifest_asset:
        try:
            manifest = get_json(manifest_asset.get('browser_download_url',''))
            declared = manifest.get('games', []) if isinstance(manifest, dict) else []
            result=[]
            for g in declared:
                if not isinstance(g, dict): continue
                asset_name = str(g.get('asset','')).strip()
                asset = by_name.get(asset_name)
                if not asset: continue
                result.append({'id':g.get('id') or safe_id(asset_name), 'title':g.get('title') or os.path.splitext(asset_name)[0], 'description':g.get('description',''), 'url':asset.get('browser_download_url',''), 'asset':asset_name, 'launch_file':g.get('launch_file','')})
            if result: return result, release.get('name') or release.get('tag_name')
        except Exception as exc:
            xbmc.log('SorbettoGames manifest ignored: %s' % exc, xbmc.LOGWARNING)
    games=[]
    for asset in assets:
        name = str(asset.get('name',''))
        lower = name.lower()
        if name.lower() in EXCLUDED_ASSETS or lower.endswith(('.md5','.sha256','.txt','.json')): continue
        if lower.endswith('.zip'):
            # Avoid showing the add-on/repository install packages as games.
            if lower.startswith(('plugin.program.sorbetto.games-', 'repository.sorbetto.games-')): continue
            title = os.path.splitext(name)[0].replace('_',' ').replace('-',' ')
            games.append({'id':safe_id(name), 'title':title, 'description':'', 'url':asset.get('browser_download_url',''), 'asset':name, 'launch_file':''})
        elif lower.endswith(ALLOWED_EXTS):
            title=os.path.splitext(name)[0].replace('_',' ').replace('-',' ')
            games.append({'id':safe_id(name), 'title':title, 'description':'', 'url':asset.get('browser_download_url',''), 'asset':name, 'launch_file':name})
    games.sort(key=lambda g:g['title'].casefold())
    return games, release.get('name') or release.get('tag_name')

def game_path(game): return os.path.join(GAMES_DIR, safe_id(game.get('id') or game.get('title')))

def installed_file(game):
    folder=game_path(game)
    if not os.path.isdir(folder): return None
    preferred=os.path.basename(str(game.get('launch_file') or ''))
    if preferred:
        for root, _, files in os.walk(folder):
            if preferred in files: return os.path.join(root, preferred)
    for root, _, files in os.walk(folder):
        for name in sorted(files):
            if name.lower().endswith(ALLOWED_EXTS): return os.path.join(root,name)
    return None

def download_game(game):
    title=str(game.get('title') or 'Game')
    url=str(game.get('url') or '')
    if not url.startswith('https://'):
        xbmcgui.Dialog().ok('SorbettoGames','Δεν υπάρχει έγκυρος σύνδεσμος λήψης για αυτό το παιχνίδι.'); return None
    folder=game_path(game); temp_file=os.path.join(GAMES_DIR,'.download-'+safe_id(game.get('id') or title)+'.part'); temp_dir=folder+'.tmp'
    progress=xbmcgui.DialogProgress(); progress.create('SorbettoGames','Λήψη: '+title)
    try:
        for p in (temp_file,):
            if os.path.exists(p): os.remove(p)
        shutil.rmtree(temp_dir,ignore_errors=True)
        req=urllib.request.Request(url,headers={'User-Agent':'SorbettoGames-Kodi/1.0.0'})
        with urllib.request.urlopen(req,timeout=90) as response, open(temp_file,'wb') as out:
            total=int(response.headers.get('Content-Length') or 0); received=0
            while True:
                if progress.iscanceled(): raise InterruptedError('Η λήψη ακυρώθηκε')
                chunk=response.read(256*1024)
                if not chunk: break
                out.write(chunk); received+=len(chunk)
                if total: progress.update(min(99,int(received*100/total)),'%.1f / %.1f MB' % (received/1048576,total/1048576))
        os.makedirs(temp_dir,exist_ok=True)
        if zipfile.is_zipfile(temp_file):
            with zipfile.ZipFile(temp_file) as zf:
                root=os.path.abspath(temp_dir)+os.sep
                for member in zf.infolist():
                    target=os.path.abspath(os.path.join(temp_dir,member.filename))
                    if not target.startswith(root): raise ValueError('Το ZIP περιέχει μη ασφαλή διαδρομή.')
                zf.extractall(temp_dir)
        else:
            name=os.path.basename(urllib.parse.urlparse(url).path) or 'game.bin'
            shutil.copy2(temp_file,os.path.join(temp_dir,name))
        if not any(f.lower().endswith(ALLOWED_EXTS) for _,_,files in os.walk(temp_dir) for f in files):
            raise ValueError('Το πακέτο δεν περιέχει αναγνωρίσιμο αρχείο παιχνιδιού (.cue/.chd/.pbp/.iso/.bin).')
        shutil.rmtree(folder,ignore_errors=True); os.replace(temp_dir,folder)
        progress.update(100,'Ολοκληρώθηκε'); notify('Εγκαταστάθηκε: '+title)
        return installed_file(game)
    except InterruptedError:
        notify('Η λήψη ακυρώθηκε: '+title)
    except Exception as exc:
        xbmc.log('SorbettoGames download failed: %s' % exc,xbmc.LOGERROR)
        xbmcgui.Dialog().ok('SorbettoGames','Αποτυχία λήψης ή εγκατάστασης.\n'+str(exc))
    finally:
        progress.close()
        try:
            if os.path.exists(temp_file): os.remove(temp_file)
        except Exception: pass
        shutil.rmtree(temp_dir,ignore_errors=True)
    return None

def launch_game(game, rom):
    if not rom or not os.path.isfile(rom):
        xbmcgui.Dialog().ok('SorbettoGames','Δεν βρέθηκε το αρχείο παιχνιδιού.'); return
    if sys.platform.startswith('win'):
        retroarch=ADDON.getSetting('retroarch_path').strip(); core=ADDON.getSetting('core_path').strip()
        if not retroarch or not os.path.isfile(retroarch):
            xbmcgui.Dialog().ok('SorbettoGames','Στις ρυθμίσεις πρόσθεσε τη διαδρομή του retroarch.exe.'); return
        if not core or not os.path.isfile(core):
            xbmcgui.Dialog().ok('SorbettoGames','Στις ρυθμίσεις πρόσθεσε τη διαδρομή του πυρήνα PCSX-ReARMed (.dll).'); return
        try: subprocess.Popen([retroarch,'-L',core,rom],cwd=os.path.dirname(retroarch))
        except Exception as exc: xbmcgui.Dialog().ok('SorbettoGames','Αποτυχία εκκίνησης.\n'+str(exc))
        return
    if xbmc.getCondVisibility('System.Platform.Android'):
        package=ADDON.getSetting('android_package').strip() or 'com.retroarch'
        # Kodi's StartAndroidActivity uses (package, action, data, MIME type, flags).
        encoded=urllib.parse.quote(rom, safe='/:')
        command='StartAndroidActivity(%s,android.intent.action.VIEW,%s,application/octet-stream)' % (package,'file://'+encoded)
        xbmc.executebuiltin(command)
        notify('Στάλθηκε αίτημα εκκίνησης στο RetroArch. Αν δεν ανοίξει, έλεγξε την έκδοση/άδειες πρόσβασης του RetroArch.')
        return
    xbmcgui.Dialog().ok('SorbettoGames','Η αυτόματη εκκίνηση δεν έχει υλοποιηθεί για αυτή την πλατφόρμα.')

def game_menu(game):
    title=str(game.get('title') or 'Game'); rom=installed_file(game)
    options=['Εκκίνηση παιχνιδιού' if rom else 'Λήψη και εγκατάσταση','Διαγραφή εγκατάστασης' if rom else 'Πληροφορίες']
    selected=xbmcgui.Dialog().select(title,options)
    if selected==0:
        if rom: launch_game(game,rom)
        else:
            rom=download_game(game)
            if rom and xbmcgui.Dialog().yesno('SorbettoGames','Η εγκατάσταση ολοκληρώθηκε. Να γίνει εκκίνηση τώρα;'): launch_game(game,rom)
    elif selected==1 and rom:
        if xbmcgui.Dialog().yesno('SorbettoGames','Να διαγραφούν τα τοπικά αρχεία αυτού του παιχνιδιού;'):
            shutil.rmtree(game_path(game),ignore_errors=True); notify('Η εγκατάσταση διαγράφηκε')
    elif selected==1: xbmcgui.Dialog().textviewer(title,str(game.get('description') or 'Δεν υπάρχει επιπλέον περιγραφή.'))

def main():
    try: games, release=load_catalog()
    except Exception as exc:
        xbmcgui.Dialog().ok('SorbettoGames','Δεν ήταν δυνατή η ανάγνωση του GitHub Release.\nΈλεγξε ότι υπάρχει Release στο repository και ότι είναι δημόσιο.\n\n'+str(exc)); return
    if not games:
        xbmcgui.Dialog().ok('SorbettoGames','Δεν βρέθηκαν παιχνίδια στο Release '+str(release or '')+'.\nΑνέβασε κάθε παιχνίδι ως ξεχωριστό ZIP asset στο GitHub Release.'); return
    labels=[]
    for game in games: labels.append(('✓ ' if installed_file(game) else '↓ ') + game['title'])
    selected=xbmcgui.Dialog().select('SorbettoGames — '+str(release or 'Παιχνίδια'),labels)
    if selected>=0: game_menu(games[selected])

if __name__=='__main__': main()
