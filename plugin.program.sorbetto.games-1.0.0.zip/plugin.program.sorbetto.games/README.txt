SorbettoGames 1.0.0 — Kodi 21 / Python 3

The add-on reads assets from the latest GitHub Release of HermesGR/SorbettoGames (or a configured repository/tag). Every game must be uploaded as its own ZIP asset. Only the selected ZIP is downloaded. Optional metadata file in the same release: sorbetto-catalog.json.

Optional manifest format:
{
  "schema": 1,
  "games": [
    {"asset":"Gran Turismo.zip", "id":"gran-turismo", "title":"Gran Turismo", "description":"...", "launch_file":"game.cue"}
  ]
}

Without a manifest, every .zip release asset except the add-on/repository packages is shown as a game; the asset filename becomes the title. For disc images, include .cue/.bin or .chd/.pbp files in each game ZIP. A single file asset is also supported when it is .chd, .pbp, .cue, .iso, or .bin, but ZIP is recommended for multi-file games.

Windows: configure the path to retroarch.exe and the PCSX-ReARMed core DLL in add-on settings. Android: configure the installed RetroArch package if it differs from com.retroarch. Android activity/file-access behavior varies by RetroArch build and Kodi version, so test on target device. The add-on does not bundle game ROMs or BIOS files.

GitHub Release layout: one release containing one ZIP per game, plus optional sorbetto-catalog.json. Use original assets you are authorised to distribute.
