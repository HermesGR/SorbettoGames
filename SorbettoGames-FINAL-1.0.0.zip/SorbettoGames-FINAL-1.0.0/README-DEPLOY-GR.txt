SORBETTOGAMES 1.0.0 — ΤΕΛΙΚΟ ΠΑΚΕΤΟ ΔΗΜΟΣΙΕΥΣΗΣ

Αρχεία:
- repository.sorbetto.games-1.0.0.zip: εγκαθιστά το Kodi repository.
- plugin.program.sorbetto.games-1.0.0.zip: το ίδιο το πρόσθετο.
- github-pages/: τα αρχεία που πρέπει να μπουν στη ρίζα του branch/folder που δημοσιεύει το GitHub Pages.

ΔΗΜΟΣΙΕΥΣΗ GITHUB PAGES
1. Αντικατάστησε/ανέβασε τα περιεχόμενα του φακέλου github-pages/ στη ρίζα του GitHub Pages για HermesGR/SorbettoGames (όχι τον ίδιο τον φάκελο ως υποφάκελο).
2. Το URL που περιμένει το repository είναι https://hermesgr.github.io/SorbettoGames/addons.xml
3. Εγκατάστησε το repository ZIP στο Kodi. Από το repository εγκατέστησε SorbettoGames.

GITHUB RELEASE ΓΙΑ ΠΑΙΧΝΙΔΙΑ
- Δημιούργησε ένα Release στο https://github.com/HermesGR/SorbettoGames/releases.
- Ανέβασε κάθε παιχνίδι ως ξεχωριστό ZIP asset. Παράδειγμα: Crash_Bandicoot.zip, Tekken_3.zip.
- Κάθε ZIP πρέπει να περιέχει τα αρχεία του συγκεκριμένου παιχνιδιού. Για CD image προτίμησε .cue μαζί με τα αντίστοιχα .bin ή ένα .chd/.pbp. Το ZIP να περιέχει τα αρχεία στην κορυφή ή σε έναν υποφάκελο.
- Το πρόσθετο διαβάζει αυτόματα τα ZIP assets του πιο πρόσφατου Release και εμφανίζει κάθε ένα ξεχωριστά. Κατεβάζει μόνο το επιλεγμένο παιχνίδι. Δεν χρειάζεται να ανεβάζεις catalog.json για απλή λίστα.
- Προαιρετικά μπορείς να συμπεριλάβεις sorbetto-catalog.json στο Release για προσαρμοσμένους τίτλους/περιγραφές. Χρησιμοποίησε το sorbetto-catalog.template.json ως βάση και όρισε το "asset" να ταιριάζει ακριβώς με το όνομα του ZIP asset.

EMULATOR
- Windows: στις ρυθμίσεις του πρόσθετου όρισε το retroarch.exe και τον πυρήνα PCSX-ReARMed DLL.
- Android TV: ρύθμισε το σωστό package name αν η εγκατάσταση RetroArch διαφέρει από com.retroarch. Η εκκίνηση Android μέσω intent εξαρτάται από την έκδοση RetroArch/Kodi και απαιτεί δοκιμή στη συσκευή.

ΣΗΜΑΝΤΙΚΟ
Δεν περιλαμβάνονται ROMs ή BIOS. Το πακέτο είναι έτοιμο ως κώδικας και feed repository, αλλά δεν μπορεί να εμφανίσει παιχνίδια μέχρι να δημοσιευτεί ένα GitHub Release με assets. Η εκκίνηση Android δεν μπορεί να θεωρηθεί επαληθευμένη χωρίς πραγματική δοκιμή στη συσκευή.
