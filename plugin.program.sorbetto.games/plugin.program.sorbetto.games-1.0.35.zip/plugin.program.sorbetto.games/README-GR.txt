SORBETTOGAMES 1.0.4 — ΕΜΦΑΝΙΣΗ / ΦΙΛΤΡΑ

Εγκατάσταση δοκιμής: plugin.program.sorbetto.games-1.0.4.zip, επάνω στην προηγούμενη έκδοση, χωρίς διαγραφή δεδομένων. Πρώτος στόχος Windows 64-bit / Kodi 21.3. Δεν εκτελέστηκε σε πραγματικό Kodi. Ο έλεγχος περιλαμβάνει σύνταξη, πακέτα, μεταδεδομένα και προσομοιωμένη λειτουργία UI.

ΑΛΛΑΓΕΣ
1. Νέο σκοτεινό οριζόντιο tech background 1920x1080, χωρίς τον μοχλό, με διακριτικό πλέγμα/γραμμές και σκοτεινή περιοχή λίστας. Χρησιμοποιείται τόσο ως addon fanart όσο και στα εσωτερικά μενού.
2. Νέο εικονίδιο 1024x1024: αφαιρέθηκαν οι μεγάλες εξωτερικές μαύρες λωρίδες από την αρχική φωτογραφία, διατηρείται ολόκληρος ο μοχλός με ασφαλή περιθώρια. Νέα paths εικόνων, ώστε να μην παραπέμπουν στις προηγούμενες cached εκδόσεις.
3. Απευθείας λίστα 24 παιχνιδιών, χωρίς αρχική επιλογή κονσόλας. PS1 πρώτα, μετά SNES, Mega Drive, NES, Amiga, Arcade.
4. Κουμπί «Κονσόλα: Όλες» στην κορυφή. Φίλτρα Όλες / PlayStation 1 / Nintendo — Super Nintendo / Sega — Mega Drive / Nintendo — NES / Commodore Amiga / Arcade. Το φίλτρο επανέρχεται σε Όλες σε κάθε νέο άνοιγμα.
5. Κάθε καταχώριση δείχνει κονσόλα και κατάσταση εγκατάστασης/διαθεσιμότητας. Κουμπιά Ανανέωση Release / Εικόνες παιχνιδιών / Ρυθμίσεις / Κλείσιμο.

ΠΛΟΗΓΗΣΗ
Ποντίκι: κουμπιά επάνω και επιλογή παιχνιδιού στη λίστα. Πληκτρολόγιο/χειριστήριο: επάνω στην πρώτη γραμμή ή αριστερά για τα φίλτρα, δεξιά/αριστερά μεταξύ κουμπιών, κάτω για τη λίστα, Enter επιλογή, Esc επιστροφή.

ΔΙΑΤΗΡΟΥΝΤΑΙ
Τα IDs και οι φάκελοι των εγκατεστημένων παιχνιδιών 1.0.1–1.0.3. Η λήψη και εκκίνηση μέσω Kodi RetroPlayer. Εξομοιωτές (εγκαθίστανται αυτόματα στο πρώτο άνοιγμα): PCSX ReARMed, Snes9x 2010, PicoDrive, FCEUmm, PUAE, FinalBurn Neo — εναλλακτικά Snes9x 2002, Genesis Plus GX, Nestopia αν ο ελαφρύς δεν υπάρχει για την πλατφόρμα, μέσω επίσημου Kodi Add-on repository. Δεν απαιτείται εξωτερικό RetroArch. Τα binaries των cores δεν περιέχονται στο ZIP. Απαιτείται Internet για εξαρτήσεις/παιχνίδια/online εικόνες και τυχόν έγκριση Kodi.
Οι εικόνες παιχνιδιών παραμένουν online από Libretro, με χειροκίνητη εντολή λήψης/cache. Δεν έχουν επιβεβαιωθεί και οι 15 και δεν περιλαμβάνονται ανεξάρτητα λογότυπα. Τα γενικά παράθυρα ρυθμίσεων/μηνυμάτων ελέγχονται από το ενεργό skin του Kodi.
Δεν περιέχονται ROMs. Arcade: εξωτερικό asset ZIP πρέπει να περιέχει αυθεντικό ZIP ROM set χωρίς μετονομασία, συμβατό με FinalBurn Neo· BIOS/parent sets δεν επιλύονται αυτόματα.

ΔΗΜΟΣΙΕΥΣΗ ΑΦΟΥ ΔΟΚΙΜΑΣΤΕΙ
Δύο ZIP εγκατάστασης στο υπάρχον Release μαζί με το crash.zip. Τα περιεχόμενα του Pages ZIP δημοσιεύονται στη σωστή πηγή GitHub Pages με διατήρηση των υποφακέλων. Η απλή προσθήκη του συμπιεσμένου Pages ZIP σε Release δεν ενημερώνει το feed. Κράτησε τα προηγούμενα ZIP για επιστροφή.


1.0.6 — Διόρθωση πακεταρίσματος: το zip περιέχει πλέον τον φάκελο plugin.program.sorbetto.games/ (το 1.0.5 είχε τα αρχεία χύμα στη ρίζα και δεν εγκαθίσταται). Καμία αλλαγή στον κώδικα.

1.0.7 — Τα παιχνίδια αναζητούνται σε ΟΛΑ τα δημοσιευμένα releases του GitHub (πριν κοίταζε μόνο το «latest», δηλαδή το v1.0.5 που δεν έχει παιχνίδια). Αν οριστεί Release tag στις ρυθμίσεις, κοιτάζει μόνο εκείνο.
       Sonic: το αναμενόμενο αρχείο έγινε sonic-the-hedgehog-sega.zip, όπως είναι στο release.
       Νέα κονσόλα Nintendo NES (εξομοιωτής game.libretro.nestopia, αρχεία .nes). Bubble Bobble και Rainbow Islands μεταφέρθηκαν από Arcade σε NES (τα αρχεία στο release είναι NES). Προστέθηκε το Joe & Mac (NES). Σύνολο 16 παιχνίδια.

1.0.8 — Αφαιρέθηκε πλήρως το PlayStation 1 (Crash Bandicoot, Tomb Raider, Gran Turismo): βγήκαν από τον κατάλογο, ο εξομοιωτής PCSX ReARMed και οι καταλήξεις PS1 βγήκαν από τον κώδικα (αργή απόδοση σε Android boxes). Σύνολο 13 παιχνίδια· η πλήρης λίστα ξεκινά από Super Nintendo.

1.0.9 — Ελαφριοί εξομοιωτές για Android boxes (Cosmote TV box, Nvidia Shield):
       SNES → Snes9x 2010 (εναλλακτικά Snes9x), Mega Drive → PicoDrive (εναλλακτικά Genesis Plus GX),
       NES → FCEUmm (εναλλακτικά Nestopia), Arcade → FinalBurn Neo (χωρίς αλλαγή).
       Στο πρώτο άνοιγμα του plugin εγκαθίστανται αυτόματα όλοι οι εξομοιωτές από το επίσημο αποθετήριο του Kodi.
       Frameskip = auto στους Snes9x 2010 και PicoDrive, ΜΙΑ φορά· αν ο χρήστης το αλλάξει μετά, δεν ξαναπειράζεται (αρχείο tuned.json στο profile).
       Οι εικόνες/φίλτρα του RetroPlayer μένουν στην προεπιλογή του Kodi (χωρίς φίλτρο), που είναι ήδη η ελαφρύτερη.

1.0.10 — Επαναφορά PlayStation 1 για δοκιμή απόδοσης: Crash Bandicoot, Tomb Raider, Gran Turismo (αναμενόμενα αρχεία crash.zip, tomb-raider.zip, gran-turismo.zip σε οποιοδήποτε release).
       Εξομοιωτής PCSX ReARMed (εγκαθίσταται αυτόματα), frameskip_type = auto ΜΙΑ φορά, όπως στους άλλους.
       Νέα κονσόλα Commodore Amiga: εξομοιωτής UAE4ARM (εγκαθίσταται αυτόματα, φτιαγμένος για ARM/Android), αρχεία .adf/.dms/.ipf.
       Δεν χρειάζεται Kickstart ROM: χωρίς αυτό ο εξομοιωτής ξεκινά με το ενσωματωμένο AROS (η συμβατότητα με παλιά παιχνίδια δεν είναι εγγυημένη).
       Προστέθηκε το Blood Money (Psygnosis, 1989) — αναμενόμενο αρχείο blood-money.zip με το .adf μέσα. Σύνολο 17 παιχνίδια.

1.0.11 — Αυτόματη αναγνώριση κονσόλας από το περιεχόμενο του zip. Αν το zip ταιριάζει με την κονσόλα του καταλόγου, τίποτα δεν αλλάζει.
       Αν όχι (π.χ. το bubble-bobble-nes.zip αντικατασταθεί με arcade ROM set), το plugin βρίσκει μόνο του την κονσόλα και τον εξομοιωτή:
       .cue/.chd/.pbp/.iso/.img → PS1, .sfc/.smc → SNES, .md/.gen → Mega Drive, .nes → NES, .adf/.dms/.ipf → Amiga, zip μέσα σε zip → Arcade (FBNeo).
       Το .bin μόνο του δεν αρκεί (κοινό σε PS1 και Mega Drive). Η κονσόλα που βρέθηκε γράφεται στο sorbetto-platform.txt μέσα στον φάκελο του παιχνιδιού.
       Παλιές εγκαταστάσεις χωρίς αυτό το αρχείο συνεχίζουν με την κονσόλα του καταλόγου.

1.0.12 — Άνοιγμα συγκεκριμένου παιχνιδιού από άλλο πρόσθετο: RunScript(plugin.program.sorbetto.games,game=<id>).
       Αν είναι εγκατεστημένο ξεκινά αμέσως, αλλιώς κατεβαίνει και μετά ξεκινά — χωρίς να ανοίξει η λίστα.
       Το χρησιμοποιεί ο Sorbetto Helper (widget «Sorbetto Games»). Άγνωστο id ή χωρίς όρισμα → η λίστα, όπως πριν.

1.0.13 — SNES: ο Snes9x αφαιρέθηκε (έκλεινε το Kodi στο Cosmote TV box, Kodi 32-bit). Σειρά πλέον: Snes9x 2010, και αν δεν υπάρχει για τη συσκευή, Snes9x 2002 (ο ελαφρύτερος, frameskip = auto μία φορά). Όπου ήδη δουλεύει ο Snes9x 2010 (Shield) δεν αλλάζει τίποτα.

1.0.14 — «Αποστολή διάγνωσης» στις Ρυθμίσεις του πρόσθετου: ανεβάζει το kodi.old.log (το log της εκτέλεσης που έκλεισε) στο paste.kodi.tv, όπως ο Kodi Logfile Uploader, και δείχνει τον σύνδεσμο. Στέλνονται οι τελευταίοι 350.000 χαρακτήρες· κωδικοί μέσα σε διευθύνσεις (user:pass@) κρύβονται. Τίποτα άλλο δεν άλλαξε.

1.0.15 — Kodi 32-bit (π.χ. Cosmote TV box): η αυτόματη αποθήκευση παιχνιδιών του Kodi (Ρυθμίσεις → Παιχνίδια → Γενικά, gamesgeneral.enableautosave) κλείνει ΜΙΑ φορά, στο πρώτο άνοιγμα του πρόσθετου.
       Αιτία: ο RetroPlayer αποθηκεύει κάθε 10" (RetroPlayerAutoSave.cpp) και στα SNES του Cosmote το Kodi έκλεινε ακριβώς στην πρώτη αποθήκευση (log κομμένο στα 10"). Με την αποθήκευση κλειστή το Super Mario World παίζει.
       Αν ο χρήστης την ξανανοίξει, δεν ξαναπειράζεται (tuned.json). Σε 64-bit Kodi (Shield) δεν αλλάζει τίποτα. Ο ήχος δεν αλλάζει.

1.0.16 — Amiga σε Kodi 32-bit (Cosmote TV box): ο UAE4ARM έκλεινε το Kodi τη στιγμή που φορτωνόταν (log: «Created process info for Android» και τέλος, χωρίς «Loaded DLL»).
       Σε 32-bit χρησιμοποιείται πλέον μόνο ο PUAE (game.libretro.uae, εγκαθίσταται αυτόματα, AROS όταν λείπει Kickstart). Σε 64-bit (Shield): UAE4ARM όπως πριν, PUAE αν λείπει.

1.0.17 — Amiga: μόνο ο PUAE (game.libretro.uae) σε όλες τις συσκευές. Ο UAE4ARM αφαιρέθηκε: δεν δούλευε ούτε στο Shield. Όπου είναι ήδη εγκατεστημένος, απλώς δεν χρησιμοποιείται· ο PUAE εγκαθίσταται με το πρώτο παιχνίδι Amiga.

1.0.18 — Κατάλογος: αφαιρέθηκαν τελείως τα Tomb Raider και Gran Turismo (PS1). Το Crash Bandicoot εμφανίζεται χωρίς «(PS1)» στον τίτλο. Σύνολο 15 παιχνίδια. Ενημερώθηκε και ο online κατάλογος (catalog.json) για το widget του Sorbetto.

1.0.19 — Blood Money: διορθώθηκε το όνομα της εικόνας (Libretro: «Blood Money», όχι «Blood Money (Europe)» που έδινε 404). Ενημερώθηκε και ο online κατάλογος.
       PUAE (Amiga): ταχύτητα δισκέτας 800% (puae_floppy_speed), ΜΙΑ φορά όπως το frameskip — πολύ πιο γρήγορη φόρτωση. Όχι Turbo: μπορεί να κολλήσει παιχνίδια με δικό τους φορτωτή.

1.0.20 — Kodi 32-bit (Cosmote TV box): κλείνει ΜΙΑ φορά και το Rewind των παιχνιδιών (Ρυθμίσεις → Παιχνίδια → Γενικά, gamesgeneral.enablerewind).
       Αιτία: με Rewind ο RetroPlayer αποθηκεύει την κατάσταση σε ΚΑΘΕ καρέ για 60" (ReversiblePlayback.cpp). Στο PS1 είναι 4,4 MB ανά καρέ και το Crash σερνόταν· με Rewind κλειστό «παίζει σφαίρα».
       Η αυτόματη αποθήκευση και το Rewind έχουν πλέον ξεχωριστό σημάδι στο tuned.json, ώστε όπου η πρώτη έκλεισε ήδη (1.0.15) να κλείσει τώρα μόνο το Rewind. Αν ο χρήστης τα ξανανοίξει, δεν ξαναπειράζονται. Σε 64-bit (Shield) δεν αλλάζει τίποτα.

1.0.21 — Επανήλθαν τα Tomb Raider και Gran Turismo (PS1), χωρίς «(PS1)» στον τίτλο όπως το Crash Bandicoot. Αναμενόμενα αρχεία: tomb-raider.zip, gran-turismo.zip. Σύνολο 17 παιχνίδια. Ενημερώθηκε και ο online κατάλογος.
       Η αυτόματη αποθήκευση και το rewind των παιχνιδιών κλείνουν πλέον μία φορά και στο Shield (64-bit), όχι μόνο σε Kodi 32-bit, γιατί και εκεί το PS1 κολλούσε.

1.0.22 — Νέα κονσόλα Sega Saturn: εξομοιωτής YabaSanshiro (εναλλακτικά Yabause), εγκαθίσταται μόνος του, με ενσωματωμένο BIOS (HLE) ώστε να μη χρειάζεται αρχείο BIOS. Νέο παιχνίδι Sega Rally Championship, 4ο στη λίστα κάτω από το Gran Turismo (αρχείο: sega-rally.zip). Τα Tomb Raider και Gran Turismo διαβάζουν πλέον τα αρχεία με τα ονόματα που ανέβηκαν (Tomb.Raider.USA.zip, Gran.Turismo.USA.zip). Σύνολο 18 παιχνίδια.

1.0.23 — (1) Εγκατάσταση με ΜΙΑ έγκριση: οι κύριοι εξομοιωτές (PCSX ReARMed, Snes9x 2010, PicoDrive, FCEUmm, PUAE, FinalBurn Neo) δηλώνονται πλέον ως εξαρτήσεις στο addon.xml, οπότε το Kodi τους εγκαθιστά μαζί με το πρόσθετο, χωρίς ξεχωριστή ερώτηση για τον καθένα. Οι εναλλακτικοί (Snes9x 2002, Genesis Plus GX, Nestopia) και ο Saturn (YabaSanshiro/Yabause) εγκαθίστανται μόνο αν χρειαστούν. (2) Οι ρυθμίσεις του πρόσθετου έδειχναν κενές ετικέτες (το settings.xml έγραφε κείμενο αντί για αριθμό μετάφρασης): προστέθηκαν strings.po σε Αγγλικά και Ελληνικά, οπότε φαίνονται «GitHub repository», «Release tag» και «Αποστολή διάγνωσης».

1.0.24 — Sega Saturn μόνο με Yabause. Ο YabaSanshiro (1.0.22) σταματούσε με «We are missing the bios, ABORTING»: στον κώδικά του το πραγματικό BIOS είναι υποχρεωτικό, ακόμα και με ενεργό HLE. Ο Yabause, όταν δεν βρει BIOS, ξεκινά με το ενσωματωμένο (HLE). Ο YabaSanshiro δεν χρησιμοποιείται πλέον, ακόμα κι αν έχει ήδη εγκατασταθεί.

1.0.25 — Saturn: ενεργό το αυτόματο frameskip του Yabause (yabause_frameskip=enabled, εκ προεπιλογής κλειστό). Όταν η εξομοίωση δεν προλαβαίνει, πετάει καρέ εικόνας αντί να καθυστερεί, ώστε ο ήχος να μη διακόπτεται (Sega Rally στο Shield: «ο ήχος χάνει λίγο»). Μπαίνει μία φορά, την πρώτη φορά που ρυθμίζεται ο Yabause· όπου έχει ήδη ρυθμιστεί, αλλάζει με το χέρι.

1.0.26 — Αναίρεση της 1.0.25: το frameskip του Yabause δεν πειράζεται πια (μένει στην προεπιλογή, κλειστό), γιατί ανοιχτό χαλούσε την κίνηση. Ο Yabause ρυθμίζεται μόνο με ενσωματωμένο BIOS, όπως στην 1.0.24.

1.0.27 — Δύο νέα παιχνίδια: Super Mario All-Stars (Super Nintendo, κάτω από το Super Mario World· αρχείο super-mario-all-stars.zip με το .sfc/.smc) και Puzzle Bobble (Arcade, κάτω από το Pang World· αρχείο puzzle-bobble.zip που περιέχει το ROM set pbobble.zip της έκδοσης Taito B-System, που δεν θέλει BIOS). Διορθώθηκαν τα εξώφυλλα πέντε arcade που δεν υπήρχαν με αυτό το όνομα στη βιβλιοθήκη εικόνων: Pac-Man (Midway), NBA Jam (rev 3.01 04-07-93), Metal Slug - Super Vehicle-001, Street Fighter (World), Double Dragon (World). Σύνολο 20 παιχνίδια.

1.0.28 — (1) Arcade: δεκτά και σκέτα ROM sets στο release (π.χ. mslug.zip με τα αρχεία του μέσα), χωρίς εξωτερικό zip· το αρχείο αποθηκεύεται με το όνομά του και ανοίγει αυτό (σημάδι sorbetto-rom.txt). Νέο πεδίο καταλόγου "bios": αρχεία BIOS από το ίδιο release που μπαίνουν στον φάκελο του παιχνιδιού (Metal Slug → neogeo.zip). Κάθε λήψη ελέγχεται ότι κατέβηκε ολόκληρη. (2) Κατάλογος με τα νέα αρχεία: Super Mario All-Stars → Super.Mario.All-Stars.USA.zip· NBA Jam → NBA Jam Tournament Edition του Super Nintendo (NBA.Jam.-.Tournament.Edition.USA.zip)· Pang World → pang.zip· Puzzle Bobble → pbobble.zip· Metal Slug → mslug.zip + neogeo.zip· Bubble Bobble → arcade bublboblr.zip (US, Ver 5.1) στη θέση του NES (το bubble-bobble-nes.zip μένει στο release). Το Rainbow Islands μένει NES: το rbisland.zip δεν έχει το cchip_b22-15.53 και θέλει και cchip.zip. (3) Αφαιρέθηκε το Gran Turismo. Σύνολο 19 παιχνίδια.

1.0.29 — Το Bubble Bobble ξανά από το NES (bobble-bubble, bubble-bobble-nes.zip), όπως πριν την 1.0.28: το arcade bublboblr.zip δεν άνοιξε. Το ίδιο id, οπότε όσοι το είχαν ήδη κατεβάσει δεν το ξανακατεβάζουν.

1.0.30 — Τέσσερα νέα Mega Drive κάτω από το Sonic, με τα ονόματα αρχείων όπως ανέβηκαν: Golden Axe (Golden.Axe.World.zip), The Revenge of Shinobi (Revenge.of.Shinobi.The.zip), Mortal Kombat (Mortal.Kombat.zip), Street Fighter II' Special Champion Edition (Street.Fighter.II.-.Special.Champion.Edition.Europe.zip). Σύνολο 23 παιχνίδια.

1.0.31 — (1) Δεκτά και αρχεία χωρίς zip στο release (π.χ. .chd), όταν η κατάληξή τους ταιριάζει με την κονσόλα· αποθηκεύονται όπως ανέβηκαν. (2) Νέο πεδίο καταλόγου "core_settings": ρυθμίσεις του εξομοιωτή που εφαρμόζονται πριν από κάθε άνοιγμα ΤΟΥ ΣΥΓΚΕΚΡΙΜΕΝΟΥ παιχνιδιού. (3) Metal Slug: πλέον η έκδοση Sega Saturn (Metal.Slug.-.Super.Vehicle-001.Japan.chd, κάτω από το Sega Rally), με κασέτα μνήμης 1MB (yabause_addon_cartridge=1M_ram) που απαιτεί το παιχνίδι· το arcade Metal Slug (mslug.zip + neogeo.zip) αφαιρέθηκε. (4) Νέο PS1: Broken Sword (Broken.Sword.-.The.Shadow.of.the.Templars.Europe.zip), κάτω από το Tomb Raider. Σύνολο 24 παιχνίδια.

1.0.32 — Τα arcade χωρίς αρχείο αντικαταστάθηκαν με εκδόσεις κονσόλας: Pac-Man → Ms. Pac-Man (NES, Ms.Pac-Man.USA.Namco.zip)· Arkanoid → Arkanoid (NES, Arkanoid.zip)· Double Dragon → Battletoads & Double Dragon (NES, Battletoads-Double.Dragon.USA.zip)· Street Fighter → Street Fighter II Turbo (Super Nintendo, Street.Fighter.II.Turbo.USA.zip)· Puzzle Bobble → Super Nintendo (Puzzle.Bobble.E.zip, νέο id ώστε να μη χρησιμοποιηθεί παλιό αντίγραφο arcade). Το Pang World μένει arcade (pang.zip). Σύνολο 24 παιχνίδια.

1.0.33 — Puzzle Bobble (Super Nintendo): διαβάζει το Puzzle.Bobble.E.2.zip, το πλήρες αρχείο που ξανανέβηκε (το GitHub πρόσθεσε το «.2» στο όνομα).

1.0.34 — Frameskip του Yabause ανά παιχνίδι (core_settings): Metal Slug → enabled (χωρίς αυτό σερνόταν και έκοβε ο ήχος), Sega Rally → disabled (με frameskip χαλούσε η κίνηση). Μπαίνει πριν από κάθε άνοιγμα του αντίστοιχου παιχνιδιού, οπότε το ένα δεν επηρεάζει το άλλο.

1.0.35 — Super Nintendo: δεκτές και οι καταλήξεις .fig και .swc (τις υποστηρίζει ο Snes9x). Το Pang World (arcade) αντικαταστάθηκε από το Super Pang του Super Nintendo (Super.Pang.E.zip, νέο id super-pang), κάτω από το Puzzle Bobble. Σύνολο 24 παιχνίδια.
