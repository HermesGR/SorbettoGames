# -*- coding: utf-8 -*-
# Υπηρεσία SorbettoGames: τρέχει στην εκκίνηση του Kodi και αμέσως μετά από εγκατάσταση/ενημέρωση του πρόσθετου.
# Μόνη δουλειά: αν οι εικόνες δεν έχουν ανανεωθεί για ΑΥΤΗ την έκδοση, τις κατεβάζει στο παρασκήνιο και τελειώνει.
import xbmc
import addon as sg

def main():
    monitor=xbmc.Monitor()
    if sg.images_version()==sg.A.getAddonInfo('version'):return
    if monitor.waitForAbort(20):return  # λίγος χρόνος για δίκτυο και αρχική οθόνη
    while xbmc.getCondVisibility('Player.HasGame'):  # όχι όσο παίζει παιχνίδι
        if monitor.waitForAbort(10):return
    sg.refresh_images(quiet=True)

main()
