import os
import sys
import zipfile
import urllib.parse
import urllib.request
import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

# Φάκελος αποθήκευσης ROMs τοπικά στο Kodi του χρήστη
DOWNLOAD_DIR = xbmcvfs.translatePath('special://profile/addon_data/plugin.program.sorbetto.games/ROMs/')

# Η λίστα με τα 3 παιχνίδια σε μορφή ZIP από τα GitHub Releases
GAMES = [
    {
        "name": "Crash Bandicoot (PS1)",
        "url": "https://github.com/HermesGR/SorbettoGames/releases/download/v1.0.0/crash.zip",
        "file": "crash.zip",
        "icon": "https://images.igdb.com/igdb/image/upload/t_cover_big/co1vbp.jpg"
    },
    {
        "name": "Gran Turismo (PS1)",
        "url": "https://github.com/HermesGR/SorbettoGames/releases/download/v1.0.0/granturismo.zip",
        "file": "granturismo.zip",
        "icon": "https://images.igdb.com/igdb/image/upload/t_cover_big/co20xb.jpg"
    },
    {
        "name": "Tomb Raider (PS1)",
        "url": "https://github.com/HermesGR/SorbettoGames/releases/download/v1.0.0/tombraider.zip",
        "file": "tombraider.zip",
        "icon": "https://images.igdb.com/igdb/image/upload/t_cover_big/co1xnz.jpg"
    }
]

def build_menu():
    HANDLE = int(sys.argv[1])
    for game in GAMES:
        li = xbmcgui.ListItem(label=game["name"])
        if game.get("icon"):
            li.setArt({'icon': game["icon"], 'thumb': game["icon"], 'poster': game["icon"]})

        url = sys.argv[0] + f"?action=play&file={urllib.parse.quote(game['file'])}&download_url={urllib.parse.quote(game['url'])}"
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)

def download_and_play(file_name, download_url):
    if not os.path.exists(DOWNLOAD_DIR):
        os.makedirs(DOWNLOAD_DIR)

    local_zip_path = os.path.join(DOWNLOAD_DIR, file_name)
    extract_folder = os.path.join(DOWNLOAD_DIR, os.path.splitext(file_name)[0])

    # Αν δεν έχει κατεβεί ήδη το zip, το κατεβάζει
    if not os.path.exists(local_zip_path) and not os.path.exists(extract_folder):
        pDialog = xbmcgui.DialogProgress()
        pDialog.create('Sorbetto Retro Games', f'Λήψη παιχνιδιού: {file_name}...')

        def _report(blocknum, blocksize, totalsize):
            if totalsize > 0:
                percent = int((blocknum * blocksize * 100) / totalsize)
                pDialog.update(percent, f'Λήψη σε εξέλιξη: {file_name}', f'{percent}% ολοκληρώθηκε')
            if pDialog.iscanceled():
                raise Exception("Cancelled")

        try:
            urllib.request.urlretrieve(download_url, local_zip_path, _report)
            pDialog.close()
        except Exception as e:
            pDialog.close()
            xbmcgui.Dialog().ok("Σφάλμα", "Η λήψη απέτυχε ή ακυρώθηκε.")
            return

    # Αποσυμπίεση του zip αν δεν έχει αποσυμπιεστεί ακόμα
    if os.path.exists(local_zip_path) and not os.path.exists(extract_folder):
        os.makedirs(extract_folder)
        with zipfile.ZipFile(local_zip_path, 'r') as zip_ref:
            zip_ref.extractall(extract_folder)

    # Εύρεση του αρχείου .cue ή .chd μέσα στον φάκελο αποσυμπίεσης
    playable_file = None
    for root, dirs, files in os.walk(extract_folder):
        for f in files:
            if f.lower().endswith('.cue') or f.lower().endswith('.chd') or f.lower().endswith('.iso'):
                playable_file = os.path.join(root, f)
                break
        if playable_file:
            break

    if playable_file:
        xbmc.Player().play(playable_file)
    else:
        xbmcgui.Dialog().ok("Σφάλμα", "Δεν βρέθηκε συμβατό αρχείο παιχνιδιού (.cue / .chd).")

if __name__ == '__main__':
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    action = params.get('action')

    if action == 'play':
        download_and_play(params.get('file'), params.get('download_url'))
    else:
        build_menu()