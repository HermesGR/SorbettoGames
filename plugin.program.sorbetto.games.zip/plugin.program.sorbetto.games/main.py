import os
import sys
import zipfile
import urllib.parse
import urllib.request
import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

# Φάκελος αποθήκευσης ROMs τοπικά στο Kodi του χρήστη
DOWNLOAD_DIR = xbmcvfs.translatePath('special://profile/addon_data/plugin.program.sorbetto.games/ROMs/')

GAMES = [
    {
        "name": "Crash Bandicoot (PS1)",
        "url": "https://github.com/HermesGR/SorbettoGames/releases/download/v1.0.0/crash.zip",
        "file": "crash.zip",
        "icon": "https://images.igdb.com/igdb/image/upload/t_cover_big/co1vbp.jpg"
    },
    {
        "name": "Gran Turismo (PS1)",
        "url": "https://github.com/HermesGR/SorbettoGames/releases/download/v1.0.0/granturismo.zip",
        "file": "granturismo.zip",
        "icon": "https://images.igdb.com/igdb/image/upload/t_cover_big/co20xb.jpg"
    },
    {
        "name": "Tomb Raider (PS1)",
        "url": "https://github.com/HermesGR/SorbettoGames/releases/download/v1.0.0/tombraider.zip",
        "file": "tombraider.zip",
        "icon": "https://images.igdb.com/igdb/image/upload/t_cover_big/co1xnz.jpg"
    }
]

def build_menu():
    HANDLE = int(sys.argv[1])
    for game in GAMES:
        li = xbmcgui.ListItem(label=game["name"])
        if game.get("icon"):
            li.setArt({'icon': game["icon"], 'thumb': game["icon"], 'poster': game["icon"]})

        url = sys.argv[0] + f"?action=play&file={urllib.parse.quote(game['file'])}&download_url={urllib.parse.quote(game['url'])}"
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)

def download_and_play(file_name, download_url):
    if not os.path.exists(DOWNLOAD_DIR):
        os.makedirs(DOWNLOAD_DIR)

    local_zip_path = os.path.join(DOWNLOAD_DIR, file_name)
    extract_folder = os.path.join(DOWNLOAD_DIR, os.path.splitext(file_name)[0])

    # Λήψη με υποστήριξη User-Agent
    if not os.path.exists(local_zip_path) and not os.path.exists(extract_folder):
        pDialog = xbmcgui.DialogProgress()
        pDialog.create('Sorbetto Retro Games', f'Λήψη παιχνιδιού: {file_name}...')

        try:
            req = urllib.request.Request(
                download_url,
                headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}
            )

            with urllib.request.urlopen(req) as response, open(local_zip_path, 'wb') as out_file:
                total_size = int(response.info().get('Content-Length', 0))
                bytes_so_far = 0
                chunk_size = 1024 * 1024

                while True:
                    chunk = response.read(chunk_size)
                    if not chunk:
                        break
                    bytes_so_far += len(chunk)
                    out_file.write(chunk)

                    if total_size > 0:
                        percent = int((bytes_so_far * 100) / total_size)
                        pDialog.update(percent, f'Λήψη σε εξέλιξη: {file_name}', f'{percent}% ολοκληρώθηκε')

                    if pDialog.iscanceled():
                        pDialog.close()
                        if os.path.exists(local_zip_path):
                            os.remove(local_zip_path)
                        return

            pDialog.close()
        except Exception as e:
            if 'pDialog' in locals():
                pDialog.close()
            if os.path.exists(local_zip_path):
                os.remove(local_zip_path)
            xbmcgui.Dialog().ok("Σφάλμα", f"Η λήψη απέτυχε: {str(e)}")
            return

    # Αποσυμπίεση του ZIP
    if os.path.exists(local_zip_path) and not os.path.exists(extract_folder):
        os.makedirs(extract_folder)
        try:
            with zipfile.ZipFile(local_zip_path, 'r') as zip_ref:
                zip_ref.extractall(extract_folder)
        except Exception as e:
            xbmcgui.Dialog().ok("Σφάλμα", "Αποτυχία αποσυμπίεσης ZIP.")
            return

    # Εύρεση του κατάλληλου αρχείου (.cue > .chd > .iso > .bin)
    playable_file = None
    valid_extensions = ('.cue', '.chd', '.iso', '.bin', '.img', '.mdf', '.pbp')

    # 1η Προτεραιότητα: Ψάχνουμε για .cue ή .chd
    for root, dirs, files in os.walk(extract_folder):
        for f in files:
            if f.lower().endswith(('.cue', '.chd', '.pbp')):
                playable_file = os.path.join(root, f)
                break
        if playable_file:
            break

    # 2η Προτεραιότητα: Αν δεν βρέθηκε .cue, ψάχνουμε για .bin / .iso
    if not playable_file:
        for root, dirs, files in os.walk(extract_folder):
            for f in files:
                if f.lower().endswith(valid_extensions):
                    playable_file = os.path.join(root, f)
                    break
            if playable_file:
                break

    if playable_file:
        xbmc.Player().play(playable_file)
    else:
        xbmcgui.Dialog().ok("Σφάλμα", "Δεν βρέθηκε συμβατό αρχείο παιχνιδιού.")

if __name__ == '__main__':
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    action = params.get('action')

    if action == 'play':
        download_and_play(params.get('file'), params.get('download_url'))
    else:
        build_menu()
