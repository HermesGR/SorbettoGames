import os
import re
import shutil
import sys
import urllib.parse
import urllib.request
import zipfile

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
ADDON_NAME = ADDON.getAddonInfo("name")
HANDLE = int(sys.argv[1])

REPO = "HermesGR/SorbettoGames"
API_URL = "https://api.github.com/repos/%s/releases/latest" % REPO

PLUGIN_PREFIXES = ("plugin.", "repository.", "script.")
GAME_META = {
    "tomb-raider-ps1.zip": ("Tomb Raider", "PlayStation"),
    "bubble-bobble-nes.zip": ("Bubble Bobble", "NES"),
    "rainbow-islands-nes.zip": ("Rainbow Islands", "NES"),
    "donkey-kong-country.zip": ("Donkey Kong Country", "SNES"),
    "super-mario-world.zip": ("Super Mario World", "SNES"),
}

PS1_EXT = (".cue", ".chd", ".pbp")
NES_EXT = (".nes",)
SNES_EXT = (".sfc", ".smc")


def log(message):
    xbmc.log("[%s] %s" % (ADDON_ID, message), xbmc.LOGINFO)


def notify(message):
    xbmcgui.Dialog().notification(ADDON_NAME, message, xbmcgui.NOTIFICATION_INFO, 4000)


def get_url_json(url):
    import json
    request = urllib.request.Request(url, headers={"User-Agent": ADDON_ID, "Accept": "application/vnd.github+json"})
    with urllib.request.urlopen(request, timeout=30) as response:
        return json.loads(response.read().decode("utf-8"))


def is_game_asset(name):
    lowered = name.lower()
    if not lowered.endswith(".zip"):
        return False
    return not any(lowered.startswith(prefix) for prefix in PLUGIN_PREFIXES)


def title_for_asset(name):
    if name in GAME_META:
        return GAME_META[name][0]
    return os.path.splitext(name)[0].replace("-", " ").replace("_", " ").title()


def platform_for_asset(name):
    if name in GAME_META:
        return GAME_META[name][1]
    lowered = name.lower()
    if "-ps1" in lowered:
        return "PlayStation"
    if "-nes" in lowered:
        return "NES"
    if "-snes" in lowered:
        return "SNES"
    return "Unknown"


def addon_data_dir():
    path = xbmcvfs.translatePath("special://profile/addon_data/%s/" % ADDON_ID)
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdir(path)
    return path


def games_dir():
    path = xbmcvfs.translatePath("special://profile/addon_data/%s/games/" % ADDON_ID)
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdir(path)
    return path


def safe_folder_name(name):
    value = re.sub(r"[^A-Za-z0-9._-]+", "_", os.path.splitext(name)[0])
    return value or "game"


def download_asset(asset, destination):
    progress = xbmcgui.DialogProgressBG()
    progress.create(ADDON_NAME, "Λήψη: %s" % asset["name"])
    try:
        request = urllib.request.Request(asset["browser_download_url"], headers={"User-Agent": ADDON_ID})
        with urllib.request.urlopen(request, timeout=60) as response, open(destination, "wb") as output:
            total = int(response.headers.get("Content-Length") or 0)
            downloaded = 0
            while True:
                chunk = response.read(1024 * 256)
                if not chunk:
                    break
                output.write(chunk)
                downloaded += len(chunk)
                if total:
                    percent = int(downloaded * 100 / total)
                    progress.update(percent, "Λήψη: %s (%d%%)" % (asset["name"], percent))
    finally:
        progress.close()


def extract_zip(zip_path, destination):
    if xbmcvfs.exists(destination):
        shutil.rmtree(destination, ignore_errors=True)
    xbmcvfs.mkdir(destination)
    with zipfile.ZipFile(zip_path, "r") as archive:
        archive.extractall(destination)


def find_game_file(folder):
    all_files = []
    for current, directories, files in os.walk(folder):
        for filename in files:
            all_files.append(os.path.join(current, filename))

    for extension in PS1_EXT:
        matches = [path for path in all_files if path.lower().endswith(extension)]
        if matches:
            return matches[0], "PlayStation"

    for extension in NES_EXT:
        matches = [path for path in all_files if path.lower().endswith(extension)]
        if matches:
            return matches[0], "NES"

    for extension in SNES_EXT:
        matches = [path for path in all_files if path.lower().endswith(extension)]
        if matches:
            return matches[0], "SNES"

    zip_matches = [path for path in all_files if path.lower().endswith(".zip")]
    if zip_matches:
        return zip_matches[0], "Arcade"

    return None, None


def launch_game(path, platform):
    log("Launching %s as %s" % (path, platform))
    xbmc.Player().play(path)


def show_games():
    try:
        release = get_url_json(API_URL)
    except Exception as error:
        log("GitHub API error: %s" % error)
        notify("Δεν ήταν δυνατή η ανάγνωση του GitHub Release.")
        return

    assets = [asset for asset in release.get("assets", []) if is_game_asset(asset["name"])]
    if not assets:
        notify("Δεν βρέθηκαν παιχνίδια στο τελευταίο Release.")
        return

    xbmcplugin.setPluginCategory(HANDLE, ADDON_NAME)
    xbmcplugin.setContent(HANDLE, "files")

    for asset in sorted(assets, key=lambda item: title_for_asset(item["name"]).lower()):
        name = asset["name"]
        title = title_for_asset(name)
        platform = platform_for_asset(name)
        item = xbmcgui.ListItem(title)
        item.setInfo("video", {"title": title, "genre": platform, "plot": "%s • %s" % (platform, name)})
        url = "plugin://%s/?asset=%s" % (ADDON_ID, urllib.parse.quote_plus(name))
        xbmcplugin.addDirectoryItem(HANDLE, url, item, False)

    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_TITLE)
    xbmcplugin.endOfDirectory(HANDLE)


def install_and_play(asset_name):
    try:
        release = get_url_json(API_URL)
    except Exception as error:
        log("GitHub API error: %s" % error)
        notify("Δεν ήταν δυνατή η ανάγνωση του GitHub Release.")
        return

    asset = next((item for item in release.get("assets", []) if item["name"] == asset_name), None)
    if not asset:
        notify("Δεν βρέθηκε το αρχείο: %s" % asset_name)
        return

    data_dir = addon_data_dir()
    zip_path = os.path.join(data_dir, asset_name)
    folder = os.path.join(games_dir(), safe_folder_name(asset_name))

    if not xbmcvfs.exists(zip_path):
        download_asset(asset, zip_path)

    try:
        extract_zip(zip_path, folder)
    except Exception as error:
        log("Extraction error: %s" % error)
        notify("Αποτυχία αποσυμπίεσης: %s" % asset_name)
        return

    game_path, detected_platform = find_game_file(folder)
    if not game_path:
        notify("Δεν βρέθηκε υποστηριζόμενο αρχείο παιχνιδιού.")
        return

    launch_game(game_path, detected_platform)


def router():
    params = urllib.parse.parse_qs(urllib.parse.urlparse(sys.argv[2]).query)
    asset = params.get("asset", [None])[0]
    if asset:
        install_and_play(asset)
    else:
        show_games()


if __name__ == "__main__":
    router()
