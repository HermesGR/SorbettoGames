# -*- coding: utf-8 -*-
import sys
import json
import os
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]

def get_catalog():
    catalog_path = os.path.join(ADDON.getAddonInfo('path'), 'resources', 'catalog.json')
    if os.path.exists(catalog_path):
        with open(catalog_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {"categories": []}

def list_categories():
    catalog = get_catalog()
    
    li_all = xbmcgui.ListItem(label="🎮 Όλα τα παιχνίδια")
    url_all = f"{BASE_URL}?action=show_all"
    xbmcplugin.addDirectoryItem(HANDLE, url_all, li_all, isFolder=True)
    
    for category in catalog.get("categories", []):
        li = xbmcgui.ListItem(label=f"📁 {category['title']}")
        url = f"{BASE_URL}?action=show_category&cat_id={category['id']}"
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)
        
    xbmcplugin.endOfDirectory(HANDLE)

def list_games(category_filter=None):
    catalog = get_catalog()
    for category in catalog.get("categories", []):
        if category_filter and category["id"] != category_filter:
            continue
            
        for game in category.get("games", []):
            li = xbmcgui.ListItem(label=game["title"])
            li.setInfo("game", {"title": game["title"], "genre": game.get("platform", "")})
            if "icon" in game:
                li.setArt({"thumb": game["icon"], "icon": game["icon"]})
            
            url = f"{BASE_URL}?action=play&game_id={game['id']}"
            xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)
            
    xbmcplugin.endOfDirectory(HANDLE)

def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring.lstrip('?')))
    action = params.get('action')

    if not action:
        list_categories()
    elif action == 'show_all':
        list_games()
    elif action == 'show_category':
        list_category_id = params.get('cat_id')
        list_games(category_filter=list_category_id)
    elif action == 'play':
        xbmcgui.Dialog().notification("Sorbetto Games", f"Έναρξη {params.get('game_id')}...", xbmcgui.NOTIFICATION_INFO, 3000)

if __name__ == '__main__':
    router(sys.argv[2])
